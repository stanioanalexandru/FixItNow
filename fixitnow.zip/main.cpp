#include "service.h"
#include "tehnician.h"
#include "receptioner.h"
#include "supervizor.h"
#include <ctime>

int main() {
    service& service = service::getInstance();

    tm data{};
    data.tm_year = 120;

    Tehnician* t = new Tehnician("Popescu", "Ion", "123", data, "Brasov");
    t->adaugaSpecializare("TV", "Samsung");

    service.adaugaAngajat(t);
    service.afiseazaAngajati();
    return 0;
}
