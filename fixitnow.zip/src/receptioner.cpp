#include "receptioner.h"

void Receptioner::adaugaCerere(int idCerere) {
    cereriInregistrate.push_back(idCerere);
}

double Receptioner::calculeazaSalariu() const {
    double salariu = 4000;
    return salariu;
}
