#include "angajat.h"
#include <iostream>

int Angajat::generatorId = 1;

Angajat::Angajat(string nume, string prenume, string cnp,
                 tm dataAngajarii, string oras)
    : id(generatorId++), nume(nume), prenume(prenume),
      cnp(cnp), dataAngajarii(dataAngajarii), oras(oras) {}

int Angajat::getId() const {
    return id;
}

string Angajat::getCNP() const {
    return cnp;
}

void Angajat::modificaNume(string numeNou, string prenumeNou) {
    nume = numeNou;
    prenume = prenumeNou;
}

void Angajat::afisare() const {
    cout << "ID: " << id << " | " << nume << " " << prenume
              << " | CNP: " << cnp << " | Oras: " << oras << "\n";
}
