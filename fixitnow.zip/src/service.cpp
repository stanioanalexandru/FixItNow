#include "service.h"
using namespace std;
service *service::instance = nullptr;

service &service::getInstance()
{
    if (!instance)
        instance = new service();
    return *instance;
}

void service::adaugaAngajat(Angajat *a)
{
    angajati.push_back(a);
}

void service::afiseazaAngajati() const
{
    if (angajati.empty())
    {
        cout << "Nu exista angajati.\n";
        return;
    }
    for (vector<Angajat *>::const_iterator it = angajati.begin(); it != angajati.end(); ++it)
    {
        (*it)->afisare();
    }
}

service::~service()
{
    for (vector<Angajat *>::iterator it = angajati.begin(); it != angajati.end(); ++it)
    {
        delete *it;
    }
}
