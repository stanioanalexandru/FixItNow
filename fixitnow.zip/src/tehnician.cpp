#include "tehnician.h"
#include "cerere_reparatie.h"
void Tehnician::adaugaSpecializare(const string& tip,
                                  const string& marca) {
    tipuri.push_back(tip);
    marci.push_back(marca);
}

bool Tehnician::poateRepara(const string& tip,
                            const string& marca) const {
    for (size_t i = 0; i < tipuri.size(); ++i) {
        if (tipuri[i] == tip && marci[i] == marca)
            return true;
    }
    return false;
}

bool Tehnician::poatePreluaCerere() const {
    return cereriActive.size() < 3;
}

void Tehnician::adaugaCerere(CerereReparatie* c) {
    cereriActive.push_back(c);
}

void Tehnician::finalizeazaCerere(CerereReparatie* c, double durata) {
    totalDurataMunca += durata;
    valoareReparatii += c->getPret();
}

double Tehnician::getDurataMunca() const {
    return totalDurataMunca;
}

double Tehnician::calculeazaSalariu() const {
    return 4000 + 0.02 * valoareReparatii;
}
