#include "cerere_reparatie.h"
double CerereReparatie::getPret() const{
    return this->pret;
}
