#pragma once
#include "Angajat.h"
class Supervizor : public Angajat {
public:
    double calculeazaSalariu() const override;
};
