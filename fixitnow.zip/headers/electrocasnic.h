#pragma once
#include <string>
using namespace std;
class Electrocasnic {
protected:
    string tip;
    string marca;
    string model;
    int anFabricatie;
    double pretCatalog;

public:
    Electrocasnic(string tip, string marca, string model,
                  int anFabricatie, double pretCatalog);

    virtual ~Electrocasnic() = default;

    string getTip() const;
    string getMarca() const;
    string getModel() const;
    double getPret() const;
    virtual void afisare() const = 0;
};
