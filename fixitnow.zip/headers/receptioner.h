#pragma once
#include "Angajat.h"
#include <vector>

class Receptioner : public Angajat {
    
    vector<int> cereriInregistrate;
public:

    void adaugaCerere(int idCerere);
    double calculeazaSalariu() const override;
};
