#pragma once
#include <vector>
#include <queue>
#include <iostream>
#include "Angajat.h"
#include "cerere_reparatie.h"
using namespace std;
class service {
    static service* instance;
    vector<Angajat*> angajati;
    queue<CerereReparatie*> cereriAsteptare;
    service() = default;

public:
    static service& getInstance();

    void adaugaAngajat(Angajat* a);
    void adaugaCerere(CerereReparatie* c);
    void afiseazaAngajati() const;
    ~service();
};
