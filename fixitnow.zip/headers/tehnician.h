#pragma once
#include "Angajat.h"
#include <vector>
#include <string>

class CerereReparatie;

class Tehnician : public Angajat {
   vector<string> tipuri;
   vector<string> marci;

   vector<CerereReparatie*> cereriActive;

    double totalDurataMunca = 0;
    double valoareReparatii = 0;

public:
    using Angajat::Angajat;

    void adaugaSpecializare(const string& tip, const string& marca);
    bool poateRepara(const string& tip, const string& marca) const;
    bool poatePreluaCerere() const;
    void adaugaCerere(CerereReparatie* c);
    void finalizeazaCerere(CerereReparatie* c, double durata);
    double getDurataMunca() const;
    double calculeazaSalariu() const override;
};
